
        <footer class="app-footer">
            <div class="wrapper">
                <span class="pull-right">云塔内测 <a href="#"><i class="fa fa-long-arrow-up"></i></a></span>
            </div>
        </footer>
        <div>
            <!-- Javascript Libs -->
            <script type="text/javascript" src="./lib/js/jquery.min.js"></script>
            <script type="text/javascript" src="./lib/js/bootstrap.min.js"></script>
            <script type="text/javascript" src="./lib/js/Chart.min.js"></script>
            <script type="text/javascript" src="./lib/js/bootstrap-switch.min.js"></script>
            <script type="text/javascript" src="./lib/js/jquery.matchHeight-min.js"></script>
            <script type="text/javascript" src="./lib/js/jquery.dataTables.min.js"></script>
            <script type="text/javascript" src="./lib/js/dataTables.bootstrap.min.js"></script>
            <script type="text/javascript" src="./lib/js/select2.full.min.js"></script>
            <script type="text/javascript" src="./lib/js/ace/ace.js"></script>
            <script type="text/javascript" src="./lib/js/ace/mode-html.js"></script>
            <script type="text/javascript" src="./lib/js/ace/theme-github.js"></script>
            <!-- Javascript -->
            <script type="text/javascript" src="./js/app.js"></script>
            <script type="text/javascript" src="./js/index.js"></script>
</body>

</html>
