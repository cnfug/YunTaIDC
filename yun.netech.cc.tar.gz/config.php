<?php

$dbconfig = array(		//网站配置数据库，必须填写！
	'host' => 'localhost',
	'user' => 'yun_netech_cc',
	'pass' => 'YYhaSkBTZrDhJMzB',
	'name' => 'yun_netech_cc',
	'port' => 3306,
);

$rootconfig = array(	//数据库ROOT配置，系统自带自助建站系统需要使用，不使用自助建站系统则不用填写！
	'host' => 'localhost',
	'user' => 'root',
	'pass' => '',
	'port' => 3306,
);

?>